{ "head": { "link": [], "vars": ["name", "homepage", "description"] },
  "results": 
    { "distinct": false,
      "ordered": true,
      "bindings": 

      [

        { "name": { "type": "literal", "xml:lang": "en", "value": "DONG Energy" }	,
          "homepage": { "type": "uri", "value": "http://www.dongenergy.com" }	,
          "description": { "type": "literal",
                           "xml:lang": "en",
                           "value": "DONG Energy is Denmark's leading energy company." 
                         }
        },

        { "name": { "type": "literal", "xml:lang": "en", "value": "Garrad Hassan" },
          "homepage": { "type": "uri", "value": "http://www.gl-garradhassan.com/" },
          "description": { "type": "literal",
                           "xml:lang":
                           "en", "value": "GL Garrad Hassan (GH) is one of..." }
        }
     ]  
   } 
}
